import uuid
from datetime import datetime, timezone
from typing import Dict, Any
from app.engines.base import BaseEngine, EngineResult
from app.services.market_data import MarketSnapshot
from app.config import settings


class DecisionEngine(BaseEngine):
    """
    Layer 15: Concludes on trade execution path (BUY, SELL, WAIT, NO TRADE),
    calculates exact institutional entry, SL, and TP, and generates a structured audit Trade Certificate.
    """
    def analyze(self, snapshot: MarketSnapshot, context: dict) -> EngineResult:
        results: Dict[str, EngineResult] = context.get("engine_results", {})
        conf_res = results.get("confidence")
        
        final_confidence = conf_res.confidence if conf_res else 0.0

        # Hard-fail checks
        failed_layer = None
        for key, res in results.items():
            if res.validation_status in ["invalid", "limit_breached", "closed"]:
                failed_layer = (key, res.explanation)
                break

        current_price = float(snapshot.df["close"].iloc[-1])
        symbol = snapshot.symbol.upper().replace("/", "")

        # Dynamically classify asset and determine precision, pip scale, and ATR parameters
        from app.services.asset_classifier import classify_asset
        asset_info = classify_asset(symbol)
        decimals = asset_info.get("decimals", 5)
        pip_unit = asset_info.get("pip_size", 0.0001)

        if asset_info.get("is_crypto", False):
            fallback_atr = max(current_price * 0.02, pip_unit * 10)
        elif "JPY" in symbol:
            fallback_atr = 0.35
        elif "XAU" in symbol or "GOLD" in symbol:
            fallback_atr = 6.50
        else:
            fallback_atr = pip_unit * 20

        # Calculate true ATR (Average True Range)
        highs = snapshot.df["high"]
        lows = snapshot.df["low"]
        closes = snapshot.df["close"]
        hl = highs - lows
        hc = (highs - closes.shift()).abs()
        lc = (lows - closes.shift()).abs()
        tr = hl.combine(hc, max).combine(lc, max)
        atr_val = tr.tail(14).mean()
        atr = float(atr_val) if (atr_val is not None and not pd_isna(atr_val) and atr_val > 0) else fallback_atr

        # Multi-layer directional bias resolution (guaranteed deterministic direction)
        struct_res = results.get("structure")
        higher_bias = results.get("higher_timeframe")
        trend_res = results.get("trend_quality")
        mom_res = results.get("momentum")
        liq_res = results.get("liquidity")

        direction = None

        if struct_res and struct_res.result in ["bullish", "bearish"]:
            direction = struct_res.result
        elif higher_bias and higher_bias.result in ["bullish", "bearish"]:
            direction = higher_bias.result
        elif trend_res and "bullish" in trend_res.result:
            direction = "bullish"
        elif trend_res and "bearish" in trend_res.result:
            direction = "bearish"
        elif mom_res and mom_res.result in ["bullish", "bearish"]:
            direction = mom_res.result
        elif liq_res and liq_res.result in ["bullish_sweep", "bearish_sweep"]:
            direction = "bullish" if liq_res.result == "bullish_sweep" else "bearish"
        else:
            # Check trading zone or 50 EMA
            zone = struct_res.metrics.get("trading_zone") if struct_res else None
            if zone == "discount":
                direction = "bullish"
            elif zone == "premium":
                direction = "bearish"
            else:
                # Compare current price to 20-period moving average
                ma20 = float(closes.tail(20).mean())
                direction = "bullish" if current_price >= ma20 else "bearish"

        # Enforce strict institutional threshold: minimum 72.0% confidence required to authorize an entry
        configured_threshold = getattr(settings, 'min_confidence_threshold', 72.0) or 72.0
        min_threshold = max(72.0, min(85.0, configured_threshold))

        # Strict SMC Premium/Discount Anti-Chasing Veto & Counter-Trend Protection
        zone = struct_res.metrics.get("trading_zone") if struct_res else None
        if not failed_layer:
            # Rule 1: Never BUY in Premium without an institutional retracement or confirmed SFP sweep
            if direction == "bullish" and zone == "premium":
                is_sweep = liq_res and liq_res.result == "bullish_sweep"
                if not is_sweep:
                    failed_layer = ("smc_zone_filter", "SMC Rule Veto: Cannot BUY in Premium zone (above equilibrium). Entering here buys the high before liquidity pullbacks.")
            # Rule 2: Never SELL in Discount without an institutional retracement or confirmed SFP sweep
            elif direction == "bearish" and zone == "discount":
                is_sweep = liq_res and liq_res.result == "bearish_sweep"
                if not is_sweep:
                    failed_layer = ("smc_zone_filter", "SMC Rule Veto: Cannot SELL in Discount zone (below equilibrium). Entering here sells the low before liquidity bounces.")
            # Rule 3: Counter-Trend Veto against 4H Trend
            if not failed_layer and higher_bias and higher_bias.result in ["bullish", "bearish"]:
                if direction == "bullish" and higher_bias.result == "bearish":
                    if not (liq_res and liq_res.result == "bullish_sweep"):
                        failed_layer = ("higher_timeframe_veto", "Counter-Trend Veto: 4H timeframe is Bearish. Long entries blocked until structural reversal confirms.")
                elif direction == "bearish" and higher_bias.result == "bullish":
                    if not (liq_res and liq_res.result == "bearish_sweep"):
                        failed_layer = ("higher_timeframe_veto", "Counter-Trend Veto: 4H timeframe is Bullish. Short entries blocked until structural reversal confirms.")

        # Altcoin Smart Liquidity & Momentum Strategy (ASLM)
        alt_meta = None
        if asset_info.get("is_crypto", False):
            try:
                from app.services.altcoin_strategy import analyze_altcoin_strategy
                btc_df = context.get("btc_df")
                alt_res = analyze_altcoin_strategy(symbol, snapshot.df, btc_df)
                if alt_res.get("valid"):
                    alt_meta = alt_res
                    # Regime filter: Guard against altcoin longs during BTC flash crash
                    if alt_res.get("btc_regime") == "btc_flash_dump" and direction == "bullish":
                        failed_layer = ("crypto_regime", "BTC Flash Dump Detected: Altcoin longs suspended until BTC finds structural support.")
                    elif alt_res.get("setup_found"):
                        # Boost confidence when altcoin relative strength and liquidity sweeps align
                        if (alt_res["bias"] == "bullish" and direction == "bullish") or (alt_res["bias"] == "bearish" and direction == "bearish"):
                            final_confidence = min(96.0, final_confidence + 6.0)
                        elif alt_res["bias"] in ["bullish", "bearish"] and direction != alt_res["bias"]:
                            final_confidence = max(40.0, final_confidence - 12.0)
            except Exception as alt_err:
                print(f"[decision.py] Altcoin strategy warning: {alt_err}")

        # Decision Matrix
        if failed_layer:
            decision = "reject"
            explanation = f"NO TRADE: Hard fail at layer '{failed_layer[0]}'. Reason: {failed_layer[1]}"
        elif final_confidence >= min_threshold:
            decision = "approve"
            action = "BUY" if direction == "bullish" else "SELL"
            aslm_note = f" [ASLM: {alt_meta['key_catalyst']}]" if (alt_meta and alt_meta.get("setup_found")) else ""
            explanation = f"{action} setup approved with {final_confidence:.1f}% confidence confluence.{aslm_note}"
        elif final_confidence >= (min_threshold - 15.0):
            decision = "wait"
            explanation = f"WAIT: Setup is promising ({direction.upper()}) but confidence ({final_confidence:.1f}%) is below {min_threshold:.0f}% threshold."
        else:
            decision = "reject"
            explanation = f"REJECTED: Low confluence score ({final_confidence:.1f}%) for {direction.upper()} setup."

        # Risk-to-Reward ratio
        rr = float(context.get("risk_reward_ratio", 3.0) or 3.0)
        if rr < 2.0:
            rr = 2.5

        # Structural levels from StructureEngine
        swing_high = float(struct_res.metrics.get("swing_high")) if (struct_res and struct_res.metrics.get("swing_high")) else None
        swing_low = float(struct_res.metrics.get("swing_low")) if (struct_res and struct_res.metrics.get("swing_low")) else None
        equilibrium = float(struct_res.metrics.get("equilibrium")) if (struct_res and struct_res.metrics.get("equilibrium")) else None

        # Precision-engineered Stop Loss and Take Profit levels
        directive = context.get("brain_directive")
        sl_buffer_val = (directive.recommended_sl_buffer_pips * pip_unit) if (directive and directive.recommended_sl_buffer_pips > 0) else 0.0

        # Institutional Retracement Entry Resolution:
        # Instead of market-chasing at candle close, place limit orders at discount/premium wholesale levels
        if direction == "bullish":
            # Wholesale discount entry: target equilibrium (50% retracement) or nearest discount block
            if equilibrium and equilibrium < current_price:
                # If current price is within tight proximity of equilibrium (within 0.15 ATR), execute market
                if (current_price - equilibrium) <= (atr * 0.15):
                    entry = current_price
                    order_type = "market"
                else:
                    # Place a Buy Limit waiting for institutional retracement into discount
                    entry = round(equilibrium, decimals)
                    order_type = "buy limit"
            else:
                entry = current_price
                order_type = "market"

            # Institutional SL below swing low with buffer
            if swing_low and swing_low < entry:
                raw_dist = (entry - swing_low) + (atr * 0.2)
                sl_dist = max(atr * 0.8, min(atr * 2.5, raw_dist))
            else:
                sl_dist = atr * 1.2

            if sl_buffer_val > 0:
                sl_dist += sl_buffer_val

            sl = round(entry - sl_dist, decimals)
            # Target external liquidity pool (swing_high) or minimum 1:3 RR
            target_proj = entry + (sl_dist * rr)
            if swing_high and swing_high > entry:
                tp = round(max(swing_high, target_proj), decimals)
            else:
                tp = round(target_proj, decimals)

        else:  # bearish
            # Wholesale premium entry: target equilibrium (50% retracement) or nearest premium block
            if equilibrium and equilibrium > current_price:
                # If current price is within tight proximity of equilibrium, execute market
                if (equilibrium - current_price) <= (atr * 0.15):
                    entry = current_price
                    order_type = "market"
                else:
                    # Place a Sell Limit waiting for institutional retracement into premium
                    entry = round(equilibrium, decimals)
                    order_type = "sell limit"
            else:
                entry = current_price
                order_type = "market"

            # Institutional SL above swing high with buffer
            if swing_high and swing_high > entry:
                raw_dist = (swing_high - entry) + (atr * 0.2)
                sl_dist = max(atr * 0.8, min(atr * 2.5, raw_dist))
            else:
                sl_dist = atr * 1.2

            if sl_buffer_val > 0:
                sl_dist += sl_buffer_val

            sl = round(entry + sl_dist, decimals)
            # Target external liquidity pool (swing_low) or minimum 1:3 RR
            target_proj = entry - (sl_dist * rr)
            if swing_low and swing_low < entry:
                tp = round(min(swing_low, target_proj), decimals)
            else:
                tp = round(target_proj, decimals)

        # Strictly enforce directional invariants:
        # For bullish: SL MUST be < entry, TP MUST be > entry
        # For bearish: SL MUST be > entry, TP MUST be < entry
        if direction == "bullish":
            if sl >= entry:
                sl = entry - (atr * 1.5)
            if tp <= entry:
                tp = entry + (abs(entry - sl) * rr)
        else:
            if sl <= entry:
                sl = entry + (atr * 1.5)
            if tp >= entry:
                tp = entry - (abs(sl - entry) * rr)

        # Expected trigger horizon
        timeframe = snapshot.timeframe
        if timeframe in ["15m", "30m"]:
            expected_trigger = "Trigger zone entry within 15-45 minutes."
        elif timeframe in ["1h"]:
            expected_trigger = "Trigger zone entry within 1-3 hours."
        else:
            expected_trigger = "Trigger zone entry within 4-12 hours."

        # Dynamically scaled lot size
        base_lot = results.get("risk").metrics.get("recommended_lot_size", 0.01) if results.get("risk") else 0.01
        if directive and directive.lot_scale_factor < 1.0 and base_lot > 0.01:
            adapted_lot = max(0.01, round(base_lot * directive.lot_scale_factor, 2))
        else:
            adapted_lot = base_lot

        # Collaboration summary
        collaboration_data = {
            "active": directive is not None,
            "brain_verdict": directive.verdict if directive else "STANDARD",
            "teacher_lesson": directive.learned_lesson if directive else "No historical loss signatures found.",
            "student_adaptation": (
                f"Applied +{directive.recommended_sl_buffer_pips:.1f} pip SL buffer ({sl_buffer_val:.5f}). Scaled lot to {adapted_lot} lots."
                if (directive and directive.recommended_sl_buffer_pips > 0)
                else "Standard 15-layer SMC execution parameters maintained."
            ),
            "collaborative_rationale": directive.collaborative_rationale if directive else "All confluences verified.",
        }

        # Construct Audit Trade Certificate
        cert_id = str(uuid.uuid4())
        certificate = {
            "trade_id": cert_id,
            "symbol": snapshot.symbol,
            "direction": "BUY" if direction == "bullish" else "SELL",
            "order_type": order_type,
            "entry_price": round(entry, decimals),
            "stop_loss": round(sl, decimals),
            "take_profit": round(tp, decimals),
            "confidence": round(final_confidence, 2),
            "risk_reward": round(rr, 2),
            "recommended_lot_size": adapted_lot,
            "dollar_risk": results.get("risk").metrics.get("dollar_risk", 0.0) if results.get("risk") else 0.0,
            "higher_timeframe_bias": higher_bias.result if higher_bias else "neutral",
            "market_structure_summary": struct_res.explanation if struct_res else "",
            "liquidity_findings": liq_res.explanation if liq_res else "",
            "institutional_zones": results.get("zones").explanation if results.get("zones") else "",
            "volume_summary": results.get("volume").explanation if results.get("volume") else "",
            "volatility_summary": results.get("volatility").explanation if results.get("volatility") else "",
            "fundamental_summary": results.get("fundamentals").explanation if results.get("fundamentals") else "",
            "correlation_summary": results.get("correlation").explanation if results.get("correlation") else "",
            "historical_pattern_summary": results.get("historical_pattern").explanation if results.get("historical_pattern") else "",
            "pattern_memory_verdict": results.get("historical_pattern").metrics.get("verdict", "APPROVED") if results.get("historical_pattern") else "APPROVED",
            "loss_autopsy_count": results.get("historical_pattern").metrics.get("diagnosed_failures", 0) if results.get("historical_pattern") else 0,
            "asset_classification": {
                "asset_class": asset_info.get("asset_class", "forex"),
                "is_crypto": asset_info.get("is_crypto", False),
                "is_altcoin": asset_info.get("is_altcoin", False),
                "sub_category": asset_info.get("sub_category", "standard")
            },
            "altcoin_strategy": alt_meta,
            "collaboration": collaboration_data,
            "decision": decision.upper(),
            "expected_trigger": expected_trigger,
            "full_explanation": explanation,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

        return EngineResult(
            result=decision,
            confidence=final_confidence,
            explanation=explanation,
            metrics={"certificate": certificate, "direction": direction, "order_type": order_type},
            validation_status="valid"
        )


def pd_isna(val) -> bool:
    try:
        import math
        return val is None or math.isnan(val)
    except Exception:
        return False
